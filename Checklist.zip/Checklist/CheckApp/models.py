from django.db import models
from datetime import date
import datetime

class Tasks(models.Model):
	task = models.CharField(max_length = 200, blank=True)
	mark = models.BooleanField(default = False, blank=True)
	completed = models.CharField(max_length = 200, blank=True)
	date1 = models.CharField(max_length = 200, blank=True)