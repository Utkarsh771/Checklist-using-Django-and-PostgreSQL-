from django.shortcuts import render, redirect
from django.views import View
from . import models
import datetime


class Home(View):
	def get(self, request):
		if (request.method == "GET"):
			all = models.Tasks.objects.all()
			dict={'k1':all}
			return render(request, "home.html", dict)
		
	def post(self, request):
		if (request.method == "POST"): 
			if ("taskDelete" in request.POST):
				print("checking...")
				if(not("mark" in request.POST.keys())):
					return redirect("/")
				marked = request.POST["mark"]
				print("got marks= ",marked)
				print("len=",len(marked))
				# for i in marked:
				print("to be deleted= ",marked)
				# print("i = ",i)
				task = models.Tasks.objects.get(pk=int(marked)) 
				task.delete() #deleting todo
				for i in marked:
					print("\n i= ",i)
				return redirect("/")
				
			if ("taskAdd" in request.POST): 
				ob = models.Tasks()
				task = request.POST["task"]
				print("task = ",task)
				completed = request.POST['completed']
				print(completed)
				dateStr = request.POST['dates']
				print('dateStr = ',dateStr)
				if(dateStr != '' and dateStr is not None):
					enddate = datetime.datetime.strptime(dateStr, '%Y-%m-%d')
					date1 = enddate.strftime('%d-%m-%Y')
				else:
					date1=' '
				print('date1 = ',date1)
				ob= models.Tasks(task=task, completed=completed, date1=date1)
				ob.save() 
				# print("saved")
				all = models.Tasks.objects.all() 
				dict={'k1':all}
				return render(request, "home.html", dict)
				# return redirect("/") 			