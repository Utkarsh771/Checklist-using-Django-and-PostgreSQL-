from django.apps import AppConfig


class CheckappConfig(AppConfig):
    name = 'CheckApp'
